import { Dashboard } from "../../components";

const index = () => {
  return <Dashboard />;
};

export default index;
