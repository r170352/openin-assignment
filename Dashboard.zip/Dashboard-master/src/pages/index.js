import { Login } from "../components";

const index = () => {
  return <Login />;
};

export default index;
