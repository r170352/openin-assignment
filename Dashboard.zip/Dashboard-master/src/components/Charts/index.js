import { default as CustomPieChart } from "./CustomPieChart";
import { default as CustomLineChart } from "./CustomLineChart";

export { CustomLineChart, CustomPieChart };
